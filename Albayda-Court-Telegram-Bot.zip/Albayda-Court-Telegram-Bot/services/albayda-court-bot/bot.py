import os
import logging
import threading
import time
import unicodedata
from collections import OrderedDict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum

import telebot
from telebot import types
import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, '.env'))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(message)s',
)

API_TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')
if API_TOKEN:
    API_TOKEN = API_TOKEN.strip()
if not API_TOKEN:
    raise RuntimeError(
        'TELEGRAM_BOT_TOKEN is not set. Create a .env file from .env.example and add your bot token.'
    )

bot = telebot.TeleBot(API_TOKEN)

LOGO_PATH = os.path.join(BASE_DIR, 'assets', 'albayda-it-logo.jpg')
CASE_NUMBER_MAX_LENGTH = 10
HIJRI_YEAR_LENGTH = 4
SEARCH_LIMIT = 3
SEARCH_WINDOW_SECONDS = 60
MAX_TRACKED_USERS = 10_000
MAX_TELEGRAM_MESSAGE_LENGTH = 4096
MOJ_BASE_URL = 'https://judg.moj.gov.ye'
CASE_SEARCH_PAGE_URL = f'{MOJ_BASE_URL}/JUDDATALIST/CustomRetCaseMaster'
CASE_SEARCH_POST_URL = f'{MOJ_BASE_URL}/JUDDATALIST/SearchCaseMaster'
COURTS_LIST_URL = f'{MOJ_BASE_URL}/JUDDATALIST/GetPlaceCourtsList'
CASE_SUBTYPES_URL = f'{MOJ_BASE_URL}/JUDDATALIST/GetKindCasePrimList'
SESSIONS_PAGE_URL = f'{MOJ_BASE_URL}/JudgmentData/CustomRetCourtSittingByDate'
SESSIONS_COURTS_URL = f'{MOJ_BASE_URL}/JudgmentData/GetSideImpList'
FIXED_SIDE_ID = '14'
FIXED_COURT_TYPE_ID = '3'
FIXED_COURT_LABEL = 'محكمة البيضاء الابتدائية'
CASE_CANCEL_BUTTON = '❌ إلغاء البحث'
CASE_FLOW_TTL_SECONDS = 15 * 60
CASE_FLOW_MAX_USERS = 10_000
SESSIONS_FLOW_TTL_SECONDS = 15 * 60
SESSIONS_FLOW_MAX_USERS = 10_000


class MinistryLookupStatus(str, Enum):
    FOUND = 'found'
    NOT_FOUND = 'not_found'
    UNAVAILABLE = 'unavailable'
    INVALID_RESPONSE = 'invalid_response'
    INVALID_QUERY = 'invalid_query'


@dataclass(frozen=True)
class MinistryLookupResult:
    status: MinistryLookupStatus
    data: str | None = None

INFO_TEXT = """
⚙️ النظام الإلكتروني المطور للاستعلام القضائي
تقنية معلومات محكمة البيضاء الابتدائية
برمجة وتصميم/ احمد حسين محسون
📲 للتواصل والدعم الفني: 734840710-771421919
"""

WELCOME_CAPTION = (
    "برمجة وتصميم/ احمد حسين محسون\n"
    "734840710-771421919\n\n"
    "مرحباً بك في بوابة تقنية معلومات محكمة البيضاء الابتدائية للاستعلام القضائي الإلكتروني عن القضايا.\n"
    "اختر الخدمة المطلوبة:"
)

DAILY_SESSIONS_BUTTON = 'الاستعلام عن الجلسات اليومية'
CASE_SEARCH_BUTTON = '🔍 الاستعلام المباشر عن قضية'

case_search_states = OrderedDict()
case_search_states_lock = threading.Lock()
sessions_search_states = OrderedDict()
sessions_search_states_lock = threading.Lock()


def parse_case_query(input_text):
    """Return normalized case number and Hijri year, or None for invalid input."""
    if not isinstance(input_text, str) or input_text.count('/') != 1:
        return None

    case_num, hijri_year = (part.strip() for part in input_text.split('/'))

    def normalize_digits(value):
        try:
            return ''.join(str(unicodedata.decimal(char)) for char in value)
        except ValueError:
            return None

    case_num = normalize_digits(case_num)
    hijri_year = normalize_digits(hijri_year)
    if case_num is None or hijri_year is None:
        return None
    if not 1 <= len(case_num) <= CASE_NUMBER_MAX_LENGTH:
        return None
    if len(hijri_year) != HIJRI_YEAR_LENGTH:
        return None
    if int(case_num) == 0 or int(hijri_year) == 0:
        return None

    return case_num, hijri_year


class UserRateLimiter:
    """Thread-safe sliding-window request limiter with bounded user tracking."""

    def __init__(self, limit, window_seconds, max_tracked_users=MAX_TRACKED_USERS, clock=time.monotonic):
        self.limit = limit
        self.window_seconds = window_seconds
        self.max_tracked_users = max_tracked_users
        self.clock = clock
        self._requests_by_user = OrderedDict()
        self._lock = threading.Lock()

    def is_limited(self, user_id):
        with self._lock:
            now = self.clock()
            requests = self._requests_by_user.get(user_id)
            if requests is not None:
                while requests and now - requests[0] >= self.window_seconds:
                    requests.popleft()
                if not requests:
                    del self._requests_by_user[user_id]
                    requests = None

            if requests is None:
                if len(self._requests_by_user) >= self.max_tracked_users:
                    self._requests_by_user.popitem(last=False)
                requests = deque()
                self._requests_by_user[user_id] = requests
            else:
                self._requests_by_user.move_to_end(user_id)

            if len(requests) >= self.limit:
                return True
            requests.append(now)
            return False


search_rate_limiter = UserRateLimiter(SEARCH_LIMIT, SEARCH_WINDOW_SECONDS)
sessions_rate_limiter = UserRateLimiter(SEARCH_LIMIT, SEARCH_WINDOW_SECONDS)


class MinistryFormError(Exception):
    """Raised when the official inquiry form no longer matches its known shape."""


def _new_moj_session():
    session = requests.Session()
    session.headers.update({
        'User-Agent': (
            'Mozilla/5.0 (compatible; AlbaydaCourtBot/1.0; '
            '+https://judg.moj.gov.ye/)'
        ),
        'Accept': 'text/html,application/json',
    })
    return session


def _normalize_label(value):
    value = unicodedata.normalize('NFKC', value or '')
    value = ''.join(
        char for char in value
        if not unicodedata.combining(char) and char != '\u0640'
    )
    return ' '.join(value.split()).casefold()


def _select_choices(soup, field_name):
    select = soup.find('select', {'name': field_name})
    if select is None:
        select = soup.find('select', {'id': field_name})
    if select is None:
        raise MinistryFormError(f'Missing official select field: {field_name}')

    choices = []
    for option in select.find_all('option'):
        value = (option.get('value') or '').strip()
        label = option.get_text(' ', strip=True)
        if value and value != '0' and label:
            choices.append((value, label))
    return choices


def _json_choices(session, url, params):
    response = session.get(url, params=params, timeout=(4, 12))
    response.raise_for_status()
    try:
        payload = response.json()
    except (ValueError, requests.exceptions.JSONDecodeError) as exc:
        raise MinistryFormError('Official options endpoint did not return JSON') from exc

    if not isinstance(payload, list):
        raise MinistryFormError('Official options endpoint returned an unexpected shape')

    choices = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        value = item.get('value')
        label = item.get('text')
        if value is None or label is None:
            continue
        value = str(value).strip()
        label = ' '.join(str(label).split())
        if value and value != '0' and label:
            choices.append((value, label))
    if not choices:
        raise MinistryFormError('Official options endpoint returned no usable choices')
    return choices


def _load_case_form(session):
    response = session.get(CASE_SEARCH_PAGE_URL, timeout=(4, 12))
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')

    token_field = soup.find('input', {'name': '__RequestVerificationToken'})
    token = token_field.get('value') if token_field else None
    if not token:
        raise MinistryFormError('The official case form has no request token')

    side_choices = _select_choices(soup, 'SideImNo')
    if not any(
        value == FIXED_SIDE_ID
        and _normalize_label(label) == _normalize_label('محافظة البيضاء')
        for value, label in side_choices
    ):
        raise MinistryFormError('The official form no longer lists Al Bayda')

    court_type_choices = _select_choices(soup, 'CourtTypeNo')
    if not any(value == FIXED_COURT_TYPE_ID for value, _ in court_type_choices):
        raise MinistryFormError('The official form no longer lists primary courts')

    case_types = _select_choices(soup, 'kindCaseNo')
    court_choices = _json_choices(
        session,
        COURTS_LIST_URL,
        {
            'CourtTypeNo': FIXED_COURT_TYPE_ID,
            'SideImNo': FIXED_SIDE_ID,
        },
    )
    matching_courts = [
        value for value, label in court_choices
        if _normalize_label(label) == _normalize_label(FIXED_COURT_LABEL)
    ]
    if len(matching_courts) != 1:
        raise MinistryFormError('The official court list did not uniquely match Al Bayda Court')

    return token, matching_courts[0], case_types


def load_case_search_options():
    """Fetch official form options for the fixed Al Bayda primary court."""
    session = _new_moj_session()
    _, court_id, case_types = _load_case_form(session)
    return court_id, case_types


def fetch_case_subtypes(case_type_id):
    session = _new_moj_session()
    return _json_choices(
        session,
        CASE_SUBTYPES_URL,
        {'KindCaseNo': str(case_type_id)},
    )


def _extract_case_result(response):
    soup = BeautifulSoup(response.text, 'html.parser')
    for unwanted in soup.find_all(['script', 'style']):
        unwanted.decompose()

    all_text = soup.get_text(' ', strip=True)
    no_result_phrases = (
        'لا توجد نتائج',
        'لم يتم العثور',
        'لا توجد بيانات',
        'لا يوجد بيانات',
    )
    if any(phrase in all_text for phrase in no_result_phrases):
        return MinistryLookupResult(MinistryLookupStatus.NOT_FOUND)
    if 'يرجى تعبئة البيانات والبحث للعثور على القضية' in all_text:
        return MinistryLookupResult(MinistryLookupStatus.INVALID_RESPONSE)

    result_block = (
        soup.find(id='resultsContainer')
        or soup.find(id='resultsTable')
        or soup.find('table')
    )
    if result_block is None:
        logging.warning(
            'Ministry case search returned no recognized result region (HTTP %s)',
            response.status_code,
        )
        return MinistryLookupResult(MinistryLookupStatus.INVALID_RESPONSE)

    rows = result_block.find_all('tr')
    if rows:
        result_text = '\n'.join(
            ' | '.join(cell.get_text(' ', strip=True) for cell in row.find_all(['th', 'td']))
            for row in rows
            if row.find_all(['th', 'td'])
        )
    else:
        result_text = result_block.get_text(' ', strip=True)
    if not result_text:
        return MinistryLookupResult(MinistryLookupStatus.NOT_FOUND)
    return MinistryLookupResult(MinistryLookupStatus.FOUND, result_text)


def fetch_case_from_moj(case_num, hijri_year, case_type_id, case_subtype_id):
    """Submit one validated lookup using the Ministry's live form and fresh token."""
    parsed_query = parse_case_query(f'{case_num}/{hijri_year}')
    if (
        parsed_query is None
        or not case_type_id
        or not case_subtype_id
    ):
        return MinistryLookupResult(MinistryLookupStatus.INVALID_QUERY)
    case_num, hijri_year = parsed_query

    session = _new_moj_session()
    try:
        token, court_id, case_types = _load_case_form(session)
        if str(case_type_id) not in {value for value, _ in case_types}:
            return MinistryLookupResult(MinistryLookupStatus.INVALID_QUERY)

        case_subtypes = _json_choices(
            session,
            CASE_SUBTYPES_URL,
            {'KindCaseNo': str(case_type_id)},
        )
        if str(case_subtype_id) not in {value for value, _ in case_subtypes}:
            return MinistryLookupResult(MinistryLookupStatus.INVALID_QUERY)

        response = session.post(
            CASE_SEARCH_POST_URL,
            data={
                'SideImNo': FIXED_SIDE_ID,
                'CourtTypeNo': FIXED_COURT_TYPE_ID,
                'PlaceCourtsNo': court_id,
                'kindCaseNo': str(case_type_id),
                'kindCasePrimeNo': str(case_subtype_id),
                # The Ministry's page builds CaseHandlyNo as year/sequence.
                'CaseHandlyNo': f'{hijri_year}/{case_num}',
                '__RequestVerificationToken': token,
            },
            headers={
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': CASE_SEARCH_PAGE_URL,
            },
            timeout=(4, 12),
        )
        response.raise_for_status()
        return _extract_case_result(response)
    except requests.exceptions.RequestException as exc:
        logging.warning('Ministry lookup unavailable (%s)', type(exc).__name__)
        return MinistryLookupResult(MinistryLookupStatus.UNAVAILABLE)
    except MinistryFormError as exc:
        logging.warning('Ministry case form was not recognized (%s)', str(exc))
        return MinistryLookupResult(MinistryLookupStatus.INVALID_RESPONSE)


def utc_today():
    """Match the Ministry page's ISO date default."""
    return datetime.now(timezone.utc).date().isoformat()


def parse_sitting_date(input_text):
    """Normalize dates accepted by the Ministry's HTML date field."""
    if not isinstance(input_text, str):
        return None
    value = input_text.strip()
    if _normalize_label(value) == _normalize_label('اليوم'):
        return utc_today()

    normalized = []
    try:
        for char in value:
            normalized.append(str(unicodedata.decimal(char)) if char.isdecimal() else char)
    except ValueError:
        return None
    value = ''.join(normalized)

    for date_format in ('%Y-%m-%d', '%Y/%m/%d', '%d/%m/%Y'):
        try:
            return datetime.strptime(value, date_format).date().isoformat()
        except ValueError:
            continue
    return None


def _load_sessions_form(session):
    response = session.get(SESSIONS_PAGE_URL, timeout=(4, 12))
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')

    token_field = soup.find('input', {'name': '__RequestVerificationToken'})
    token = token_field.get('value') if token_field else None
    if not token:
        raise MinistryFormError('The official daily sessions form has no request token')

    province_choices = _select_choices(soup, 'SideImNo')
    if not province_choices:
        raise MinistryFormError('The official daily sessions form has no provinces')
    if soup.find('select', {'name': 'PlaceCourtsNo'}) is None:
        raise MinistryFormError('The official daily sessions form has no court field')
    if soup.find('input', {'name': 'SittingDate'}) is None:
        raise MinistryFormError('The official daily sessions form has no date field')
    return token, province_choices


def load_sessions_provinces():
    """Fetch province choices from the current official daily sessions form."""
    session = _new_moj_session()
    _, province_choices = _load_sessions_form(session)
    return province_choices


def fetch_sessions_courts(province_id):
    """Fetch official courts for a province selected from the sessions form."""
    session = _new_moj_session()
    _, province_choices = _load_sessions_form(session)
    if str(province_id) not in {value for value, _ in province_choices}:
        raise MinistryFormError('The selected province is not in the official list')
    return _json_choices(
        session,
        SESSIONS_COURTS_URL,
        {'sideImNo': str(province_id)},
    )


def _extract_sessions_result(response):
    soup = BeautifulSoup(response.text, 'html.parser')
    for unwanted in soup.find_all(['script', 'style']):
        unwanted.decompose()

    result_block = (
        soup.find(id='resultsContainer')
        or soup.find(id='resultsTable')
        or soup.find('table')
    )
    if result_block is None:
        logging.warning(
            'Ministry daily sessions returned no recognized result region (HTTP %s)',
            response.status_code,
        )
        return MinistryLookupResult(MinistryLookupStatus.INVALID_RESPONSE)

    result_text = result_block.get_text(' ', strip=True)
    no_result_phrases = (
        'لا توجد نتائج',
        'لا يوجد نتائج',
        'لا توجد جلسات',
        'لا يوجد جلسات',
        'لا توجد بيانات',
        'لم يتم العثور على جلسات',
    )
    if any(phrase in result_text for phrase in no_result_phrases):
        return MinistryLookupResult(MinistryLookupStatus.NOT_FOUND)
    if 'يرجى اختيار المحكمة والتاريخ ثم الضغط على بحث' in result_text:
        return MinistryLookupResult(MinistryLookupStatus.INVALID_RESPONSE)

    rows = result_block.find_all('tr')
    if rows:
        result_text = '\n'.join(
            ' | '.join(
                cell.get_text(' ', strip=True)
                for cell in row.find_all(['th', 'td'])
            )
            for row in rows
            if row.find_all(['th', 'td'])
        )
    if not result_text:
        return MinistryLookupResult(MinistryLookupStatus.NOT_FOUND)
    return MinistryLookupResult(MinistryLookupStatus.FOUND, result_text)


def fetch_daily_sessions_from_moj(province_id, court_id, sitting_date):
    """Submit the official daily sessions form using a fresh page token."""
    normalized_date = parse_sitting_date(sitting_date)
    if not normalized_date or not province_id or not court_id:
        return MinistryLookupResult(MinistryLookupStatus.INVALID_QUERY)

    session = _new_moj_session()
    try:
        token, province_choices = _load_sessions_form(session)
        province_id = str(province_id)
        court_id = str(court_id)
        if province_id not in {value for value, _ in province_choices}:
            return MinistryLookupResult(MinistryLookupStatus.INVALID_QUERY)

        court_choices = _json_choices(
            session,
            SESSIONS_COURTS_URL,
            {'sideImNo': province_id},
        )
        if court_id not in {value for value, _ in court_choices}:
            return MinistryLookupResult(MinistryLookupStatus.INVALID_QUERY)

        response = session.post(
            SESSIONS_PAGE_URL,
            data={
                'SideImNo': province_id,
                'PlaceCourtsNo': court_id,
                'SittingDate': normalized_date,
                '__RequestVerificationToken': token,
            },
            headers={
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': SESSIONS_PAGE_URL,
            },
            timeout=(4, 12),
        )
        response.raise_for_status()
        return _extract_sessions_result(response)
    except requests.exceptions.RequestException as exc:
        logging.warning('Ministry daily sessions unavailable (%s)', type(exc).__name__)
        return MinistryLookupResult(MinistryLookupStatus.UNAVAILABLE)
    except MinistryFormError as exc:
        logging.warning('Ministry sessions form was not recognized (%s)', str(exc))
        return MinistryLookupResult(MinistryLookupStatus.INVALID_RESPONSE)


def _case_state_key(message):
    user_id = getattr(getattr(message, 'from_user', None), 'id', None)
    chat_id = getattr(getattr(message, 'chat', None), 'id', None)
    if user_id is None or chat_id is None:
        return None
    return chat_id, user_id


def _save_case_state(message, state):
    key = _case_state_key(message)
    if key is None:
        return False
    now = time.monotonic()
    with case_search_states_lock:
        expired = [
            state_key for state_key, value in case_search_states.items()
            if now - value.get('updated_at', now) >= CASE_FLOW_TTL_SECONDS
        ]
        for state_key in expired:
            case_search_states.pop(state_key, None)
        if key not in case_search_states and len(case_search_states) >= CASE_FLOW_MAX_USERS:
            case_search_states.popitem(last=False)
        state['updated_at'] = now
        case_search_states[key] = state
        case_search_states.move_to_end(key)
    return True


def _get_case_state(message):
    key = _case_state_key(message)
    if key is None:
        return None
    now = time.monotonic()
    with case_search_states_lock:
        state = case_search_states.get(key)
        if state is None:
            return None
        if now - state.get('updated_at', now) >= CASE_FLOW_TTL_SECONDS:
            del case_search_states[key]
            return None
        state['updated_at'] = now
        case_search_states.move_to_end(key)
        return state


def _clear_case_state(message):
    key = _case_state_key(message)
    if key is None:
        return
    with case_search_states_lock:
        case_search_states.pop(key, None)


def _save_sessions_state(message, state):
    key = _case_state_key(message)
    if key is None:
        return False
    now = time.monotonic()
    with sessions_search_states_lock:
        expired = [
            state_key for state_key, value in sessions_search_states.items()
            if now - value.get('updated_at', now) >= SESSIONS_FLOW_TTL_SECONDS
        ]
        for state_key in expired:
            sessions_search_states.pop(state_key, None)
        if key not in sessions_search_states and len(sessions_search_states) >= SESSIONS_FLOW_MAX_USERS:
            sessions_search_states.popitem(last=False)
        state['updated_at'] = now
        sessions_search_states[key] = state
        sessions_search_states.move_to_end(key)
    return True


def _get_sessions_state(message):
    key = _case_state_key(message)
    if key is None:
        return None
    now = time.monotonic()
    with sessions_search_states_lock:
        state = sessions_search_states.get(key)
        if state is None:
            return None
        if now - state.get('updated_at', now) >= SESSIONS_FLOW_TTL_SECONDS:
            del sessions_search_states[key]
            return None
        state['updated_at'] = now
        sessions_search_states.move_to_end(key)
        return state


def _clear_sessions_state(message):
    key = _case_state_key(message)
    if key is None:
        return
    with sessions_search_states_lock:
        sessions_search_states.pop(key, None)


def _choice_keyboard(choices, include_cancel=True):
    markup = types.ReplyKeyboardMarkup(
        resize_keyboard=True,
        row_width=2,
        one_time_keyboard=True,
    )
    for _, label in choices:
        markup.add(types.KeyboardButton(label))
    if include_cancel:
        markup.add(types.KeyboardButton(CASE_CANCEL_BUTTON))
    return markup


def _find_choice(text, choices):
    target = _normalize_label(text)
    return next(
        (
            (value, label) for value, label in choices
            if _normalize_label(label) == target
        ),
        None,
    )


def begin_case_search(message):
    bot.send_chat_action(message.chat.id, 'typing')
    wait_msg = bot.reply_to(
        message,
        '⏳ جاري جلب خيارات البحث الرسمية من وزارة العدل...',
    )
    try:
        court_id, case_types = load_case_search_options()
    except requests.exceptions.RequestException as exc:
        logging.warning('Ministry case form unavailable (%s)', type(exc).__name__)
        bot.edit_message_text(
            '⚠️ تعذر الاتصال ببوابة وزارة العدل حالياً. لم يُرسل أي استعلام؛ حاول لاحقاً.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return
    except MinistryFormError as exc:
        logging.warning('Ministry case form was not recognized (%s)', str(exc))
        bot.edit_message_text(
            '⚠️ تعذر قراءة خيارات نموذج وزارة العدل الحالي، لذلك لم أبدأ البحث.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return

    if not case_types:
        bot.edit_message_text(
            '⚠️ لم يعرض نموذج الوزارة أنواع قضايا صالحة للاستعلام.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return

    state = {
        'step': 'case_type',
        'court_id': court_id,
        'case_types': case_types,
    }
    if not _save_case_state(message, state):
        bot.edit_message_text(
            '⚠️ تعذر بدء الاستعلام. افتح المحادثة الخاصة بالبوت ثم حاول مجدداً.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return

    bot.edit_message_text(
        '✅ تم تثبيت الجهة: محافظة البيضاء، ونوع المحكمة: ابتدائية، '
        f'والمحكمة: {FIXED_COURT_LABEL}.',
        chat_id=message.chat.id,
        message_id=wait_msg.message_id,
    )
    bot.send_message(
        message.chat.id,
        'اختر نوع القضية:',
        reply_markup=_choice_keyboard(case_types),
    )


def handle_case_search_step(message, state):
    text = getattr(message, 'text', '') or ''
    if state['step'] == 'case_type':
        selected = _find_choice(text, state['case_types'])
        if selected is None:
            bot.reply_to(
                message,
                'اختر نوع القضية من الأزرار الظاهرة، أو ألغِ البحث.',
                reply_markup=_choice_keyboard(state['case_types']),
            )
            return
        try:
            subtypes = fetch_case_subtypes(selected[0])
        except requests.exceptions.RequestException as exc:
            logging.warning('Ministry case subtypes unavailable (%s)', type(exc).__name__)
            _clear_case_state(message)
            bot.reply_to(
                message,
                '⚠️ تعذر جلب الأنواع الفرعية من وزارة العدل. لم يُرسل بحث؛ ابدأ مجدداً لاحقاً.',
                reply_markup=types.ReplyKeyboardRemove(),
            )
            return
        except MinistryFormError as exc:
            logging.warning('Ministry case subtypes were not recognized (%s)', str(exc))
            _clear_case_state(message)
            bot.reply_to(
                message,
                '⚠️ تعذر قراءة الأنواع الفرعية الحالية من وزارة العدل.',
                reply_markup=types.ReplyKeyboardRemove(),
            )
            return

        state.update({
            'step': 'case_subtype',
            'case_type_id': selected[0],
            'case_type_label': selected[1],
            'case_subtypes': subtypes,
        })
        _save_case_state(message, state)
        bot.reply_to(
            message,
            f'اختر النوع الفرعي للقضية {selected[1]}:',
            reply_markup=_choice_keyboard(subtypes),
        )
        return

    if state['step'] == 'case_subtype':
        selected = _find_choice(text, state['case_subtypes'])
        if selected is None:
            bot.reply_to(
                message,
                'اختر النوع الفرعي من الأزرار الظاهرة، أو ألغِ البحث.',
                reply_markup=_choice_keyboard(state['case_subtypes']),
            )
            return
        state.update({
            'step': 'case_number',
            'case_subtype_id': selected[0],
            'case_subtype_label': selected[1],
        })
        _save_case_state(message, state)
        bot.reply_to(
            message,
            'أدخل رقم القضية ثم السنة الهجرية بهذا الشكل: 101/1446',
            reply_markup=types.ReplyKeyboardRemove(),
        )
        return

    if state['step'] == 'case_number':
        if parse_case_query(text) is None:
            bot.reply_to(
                message,
                '⚠️ الصيغة غير صحيحة. أدخل رقم القضية من 1 إلى 10 أرقام ثم السنة الهجرية من 4 أرقام، مثل: 101/1446.',
            )
            return
        _clear_case_state(message)
        process_search(
            message,
            state['case_type_id'],
            state['case_subtype_id'],
            state['case_type_label'],
            state['case_subtype_label'],
        )


def begin_daily_sessions_search(message):
    bot.send_chat_action(message.chat.id, 'typing')
    wait_msg = bot.reply_to(
        message,
        '⏳ جاري تحميل المحافظات المتاحة من صفحة الجلسات الرسمية...',
    )
    try:
        provinces = load_sessions_provinces()
    except requests.exceptions.RequestException as exc:
        logging.warning('Ministry daily sessions form unavailable (%s)', type(exc).__name__)
        bot.edit_message_text(
            '⚠️ تعذر الاتصال ببوابة وزارة العدل حالياً. حاول لاحقاً.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return
    except MinistryFormError as exc:
        logging.warning('Ministry daily sessions form was not recognized (%s)', str(exc))
        bot.edit_message_text(
            '⚠️ تعذر قراءة خيارات نموذج الجلسات الحالي، لذلك لم أبدأ البحث.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return

    state = {'step': 'province', 'provinces': provinces}
    if not provinces or not _save_sessions_state(message, state):
        bot.edit_message_text(
            '⚠️ لا تتوفر محافظات صالحة للاختيار حالياً.',
            chat_id=message.chat.id,
            message_id=wait_msg.message_id,
        )
        return

    bot.edit_message_text(
        '✅ تم تحميل المحافظات من نموذج وزارة العدل.',
        chat_id=message.chat.id,
        message_id=wait_msg.message_id,
    )
    bot.send_message(
        message.chat.id,
        'اختر المحافظة:',
        reply_markup=_choice_keyboard(provinces),
    )


def handle_sessions_search_step(message, state):
    text = getattr(message, 'text', '') or ''
    if state['step'] == 'province':
        selected = _find_choice(text, state['provinces'])
        if selected is None:
            bot.reply_to(
                message,
                'اختر المحافظة من الأزرار الظاهرة، أو ألغِ البحث.',
                reply_markup=_choice_keyboard(state['provinces']),
            )
            return
        try:
            courts = fetch_sessions_courts(selected[0])
        except requests.exceptions.RequestException as exc:
            logging.warning('Ministry sessions courts unavailable (%s)', type(exc).__name__)
            _clear_sessions_state(message)
            bot.reply_to(
                message,
                '⚠️ تعذر تحميل المحاكم من وزارة العدل. ابدأ الاستعلام مجدداً لاحقاً.',
                reply_markup=types.ReplyKeyboardRemove(),
            )
            return
        except MinistryFormError as exc:
            logging.warning('Ministry sessions courts were not recognized (%s)', str(exc))
            _clear_sessions_state(message)
            bot.reply_to(
                message,
                '⚠️ تعذر قراءة المحاكم المتاحة لهذه المحافظة.',
                reply_markup=types.ReplyKeyboardRemove(),
            )
            return
        if not courts:
            _clear_sessions_state(message)
            bot.reply_to(
                message,
                '⚠️ لا توجد محاكم متاحة في المحافظة المحددة.',
                reply_markup=types.ReplyKeyboardRemove(),
            )
            return
        state.update({
            'step': 'court',
            'province_id': selected[0],
            'province_label': selected[1],
            'courts': courts,
        })
        _save_sessions_state(message, state)
        bot.reply_to(
            message,
            f'اختر المحكمة في {selected[1]}:',
            reply_markup=_choice_keyboard(courts),
        )
        return

    if state['step'] == 'court':
        selected = _find_choice(text, state['courts'])
        if selected is None:
            bot.reply_to(
                message,
                'اختر المحكمة من الأزرار الظاهرة، أو ألغِ البحث.',
                reply_markup=_choice_keyboard(state['courts']),
            )
            return
        state.update({
            'step': 'date',
            'court_id': selected[0],
            'court_label': selected[1],
        })
        _save_sessions_state(message, state)
        bot.reply_to(
            message,
            'أدخل تاريخ الجلسة بصيغة YYYY-MM-DD، أو أرسل «اليوم» '
            f'للبحث بتاريخ {utc_today()}.',
            reply_markup=types.ReplyKeyboardRemove(),
        )
        return

    if state['step'] == 'date':
        sitting_date = parse_sitting_date(text)
        if sitting_date is None:
            bot.reply_to(
                message,
                '⚠️ التاريخ غير صحيح. استخدم YYYY-MM-DD، مثل 2026-10-21، '
                'أو أرسل «اليوم».',
            )
            return
        _clear_sessions_state(message)
        process_daily_sessions_search(
            message,
            state['province_id'],
            state['province_label'],
            state['court_id'],
            state['court_label'],
            sitting_date,
        )


def process_daily_sessions_search(
    message,
    province_id,
    province_label,
    court_id,
    court_label,
    sitting_date,
):
    user_id = getattr(getattr(message, 'from_user', None), 'id', None)
    if user_id is None or sessions_rate_limiter.is_limited(user_id):
        bot.reply_to(
            message,
            '⏱️ تجاوزت الحد المسموح للاستعلامات (3 طلبات خلال دقيقة). '
            'يرجى الانتظار قبل المحاولة مرة أخرى.',
        )
        return

    bot.send_chat_action(message.chat.id, 'typing')
    wait_msg = bot.reply_to(
        message,
        '⏳ جاري جلب جدول الجلسات من بوابة وزارة العدل...',
    )
    lookup = fetch_daily_sessions_from_moj(
        province_id,
        court_id,
        sitting_date,
    )
    header = (
        f'📅 جلسات يوم {sitting_date}\n'
        f'المحافظة: {province_label}\n'
        f'المحكمة: {court_label}\n\n'
    )

    if lookup.status == MinistryLookupStatus.FOUND:
        response = header + lookup.data
    elif lookup.status == MinistryLookupStatus.NOT_FOUND:
        response = (
            header
            + 'لا توجد جلسات مسجلة لهذه المحكمة في التاريخ المحدد.'
        )
    elif lookup.status == MinistryLookupStatus.UNAVAILABLE:
        response = (
            '⚠️ تعذر الاتصال ببوابة وزارة العدل حالياً، لذلك لم يكتمل الاستعلام. '
            'يرجى المحاولة لاحقاً.'
        )
    else:
        response = (
            '⚠️ وصل رد غير متوقع من بوابة وزارة العدل، لذلك لم أتمكن من تأكيد '
            'جدول الجلسات. يرجى المحاولة لاحقاً.'
        )

    if len(response) > MAX_TELEGRAM_MESSAGE_LENGTH:
        response = (
            response[:MAX_TELEGRAM_MESSAGE_LENGTH - 64]
            + '\n\n… تم اختصار بقية النتيجة لطول الرسالة.'
        )
    bot.edit_message_text(
        response,
        chat_id=message.chat.id,
        message_id=wait_msg.message_id,
    )


@bot.message_handler(commands=['start', 'help'])
def send_welcome(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
    btn_search = types.KeyboardButton('🔍 الاستعلام المباشر عن قضية')
    btn_daily_sessions = types.KeyboardButton(DAILY_SESSIONS_BUTTON)
    btn_info = types.KeyboardButton('ℹ️ معلومات النظام والملكية')
    markup.add(btn_search, btn_daily_sessions, btn_info)

    with open(LOGO_PATH, 'rb') as logo:
        bot.send_photo(
            message.chat.id,
            photo=logo,
            caption=WELCOME_CAPTION,
            reply_markup=markup,
        )


@bot.message_handler(func=lambda message: True)
def handle_menu(message):
    text = getattr(message, 'text', None)
    state = _get_case_state(message)
    sessions_state = _get_sessions_state(message)

    if text == CASE_CANCEL_BUTTON:
        _clear_case_state(message)
        _clear_sessions_state(message)
        bot.reply_to(
            message,
            'تم إلغاء الاستعلام. استخدم أزرار القائمة لبدء خدمة أخرى.',
            reply_markup=types.ReplyKeyboardRemove(),
        )
        return

    menu_buttons = {
        CASE_SEARCH_BUTTON,
        DAILY_SESSIONS_BUTTON,
        'ℹ️ معلومات النظام والملكية',
    }
    if state is not None and text not in menu_buttons:
        handle_case_search_step(message, state)
        return
    if sessions_state is not None and text not in menu_buttons:
        handle_sessions_search_step(message, sessions_state)
        return
    if state is not None:
        _clear_case_state(message)
    if sessions_state is not None:
        _clear_sessions_state(message)

    if text == 'ℹ️ معلومات النظام والملكية':
        bot.reply_to(message, INFO_TEXT, parse_mode='Markdown')
    elif text == DAILY_SESSIONS_BUTTON:
        begin_daily_sessions_search(message)
    elif text == CASE_SEARCH_BUTTON:
        begin_case_search(message)
    else:
        bot.reply_to(message, "الرجاء استخدام الأزرار المتاحة في القائمة أسفل الشاشة.")


def process_search(
    message,
    case_type_id=None,
    case_subtype_id=None,
    case_type_label=None,
    case_subtype_label=None,
):
    parsed_query = parse_case_query(getattr(message, 'text', None))
    if parsed_query is None:
        bot.reply_to(
            message,
            "⚠️ صيغة المدخلات غير صحيحة. أدخل رقم قضية من 1 إلى 10 أرقام، ثم سنة هجرية من 4 أرقام، "
            "مثل: `101/1446`.",
            parse_mode='Markdown',
        )
        return

    user_id = getattr(getattr(message, 'from_user', None), 'id', None)
    if user_id is None or search_rate_limiter.is_limited(user_id):
        bot.reply_to(
            message,
            "⏱️ تجاوزت الحد المسموح للاستعلامات (3 طلبات خلال دقيقة). يرجى الانتظار قبل المحاولة مرة أخرى.",
        )
        return

    case_num, hijri_year = parsed_query
    bot.send_chat_action(message.chat.id, 'typing')
    wait_msg = bot.reply_to(
        message,
        '⏳ جاري الاتصال ببوابة وزارة العدل للتحقق من بيانات القضية...',
    )
    lookup = fetch_case_from_moj(
        case_num,
        hijri_year,
        case_type_id,
        case_subtype_id,
    )

    if lookup.status == MinistryLookupStatus.FOUND:
        classification = ''
        if case_type_label and case_subtype_label:
            classification = (
                f'التصنيف: {case_type_label} - {case_subtype_label}\n'
            )
        response = (
            f'⚖️ نتيجة الاستعلام للقضية رقم ({case_num} / {hijri_year} هـ):\n\n'
            f'{classification}'
            f'{lookup.data}\n\n'
            f'----------------------------------\n'
            f'{INFO_TEXT.strip()}'
        )
    elif lookup.status == MinistryLookupStatus.NOT_FOUND:
        response = (
            f'❌ لم يعثر موقع الوزارة على بيانات للقضية رقم ({case_num} / {hijri_year} هـ).\n'
            f'يرجى التأكد من الرقم والسنة أو مراجعة المحكمة مباشرة.\n\n'
            f'----------------------------------\n'
            f'{INFO_TEXT.strip()}'
        )
    elif lookup.status == MinistryLookupStatus.UNAVAILABLE:
        response = (
            '⚠️ تعذر الاتصال ببوابة وزارة العدل حالياً، لذلك لم يكتمل الاستعلام. '
            'هذا لا يعني عدم وجود القضية؛ يرجى المحاولة لاحقاً.\n\n'
            f'----------------------------------\n'
            f'{INFO_TEXT.strip()}'
        )
    else:
        response = (
            '⚠️ وصل رد غير متوقع من بوابة وزارة العدل، لذلك لم أتمكن من تأكيد نتيجة القضية. '
            'يرجى المحاولة لاحقاً.\n\n'
            f'----------------------------------\n'
            f'{INFO_TEXT.strip()}'
        )

    if len(response) > MAX_TELEGRAM_MESSAGE_LENGTH:
        response = (
            response[:MAX_TELEGRAM_MESSAGE_LENGTH - 64]
            + '\n\n… تم اختصار بقية النتيجة لطول الرسالة.'
        )

    bot.edit_message_text(
        response,
        chat_id=message.chat.id,
        message_id=wait_msg.message_id,
    )


if __name__ == '__main__':
    logging.info('🚀 البوت المرتبط مباشرة بموقع وزارة العدل يعمل الآن...')
    bot.infinity_polling(timeout=60, long_polling_timeout=60)
