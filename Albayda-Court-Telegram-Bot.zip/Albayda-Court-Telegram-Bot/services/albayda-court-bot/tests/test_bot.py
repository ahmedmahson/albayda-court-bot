import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

os.environ['TELEGRAM_BOT_TOKEN'] = '123456789:unit-test-token'
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import bot as court_bot


class ParseCaseQueryTests(unittest.TestCase):
    def test_parses_ascii_digits_and_surrounding_whitespace(self):
        self.assertEqual(court_bot.parse_case_query(' 150 / 1445 '), ('150', '1445'))

    def test_normalizes_arabic_indic_digits(self):
        self.assertEqual(court_bot.parse_case_query('١٠١/١٤٤٦'), ('101', '1446'))

    def test_rejects_non_numeric_values(self):
        for value in ('abc/1446', '101/14a6', '١a١/١٤٤٦'):
            with self.subTest(value=value):
                self.assertIsNone(court_bot.parse_case_query(value))

    def test_rejects_missing_or_multiple_separators(self):
        for value in ('1011446', '101/1446/1', '/1446', '101/'):
            with self.subTest(value=value):
                self.assertIsNone(court_bot.parse_case_query(value))

    def test_rejects_unreasonable_lengths_and_zero_values(self):
        for value in ('12345678901/1446', '101/144', '101/14455', '0/1446', '101/0000'):
            with self.subTest(value=value):
                self.assertIsNone(court_bot.parse_case_query(value))

    @patch.object(court_bot, '_new_moj_session')
    def test_invalid_query_never_calls_ministry(self, new_session):
        result = court_bot.fetch_case_from_moj('invalid', '1446', '1', '11')
        self.assertEqual(result.status, court_bot.MinistryLookupStatus.INVALID_QUERY)
        new_session.assert_not_called()

    @staticmethod
    def make_response(body='', status_code=200, json_body=None):
        response = SimpleNamespace(
            text=body,
            status_code=status_code,
            raise_for_status=Mock(),
        )
        if json_body is not None:
            response.json = Mock(return_value=json_body)
        else:
            response.json = Mock(side_effect=ValueError('not JSON'))
        return response

    def make_form_page(self):
        return self.make_response(
            '<form>'
            '<input type="hidden" name="__RequestVerificationToken" value="fixture-token">'
            '<select name="SideImNo"><option value="14">محافظة البيضاء</option></select>'
            '<select name="CourtTypeNo"><option value="3">محكمة ابتدائية</option></select>'
            '<select name="kindCaseNo"><option value="1">جزائية</option></select>'
            '</form>'
        )

    def make_ministry_session(self, result_html):
        return SimpleNamespace(
            headers={},
            get=Mock(side_effect=[
                self.make_form_page(),
                self.make_response(json_body=[
                    {'value': '145', 'text': 'محكمة البيضاء الابتدائية'},
                ]),
                self.make_response(json_body=[
                    {'value': '11', 'text': 'نوع فرعي رسمي'},
                ]),
            ]),
            post=Mock(return_value=self.make_response(result_html)),
        )

    def test_extracts_case_result_from_ministry_response(self):
        response = self.make_response(
            '<div id="resultsContainer"><table><tr><td>تفاصيل القضية</td></tr></table></div>'
        )
        result = court_bot._extract_case_result(response)
        self.assertEqual(result.status, court_bot.MinistryLookupStatus.FOUND)
        self.assertEqual(result.data, 'تفاصيل القضية')

    def test_distinguishes_no_results_from_site_failure(self):
        response = self.make_response(
            '<div id="resultsContainer">لا توجد نتائج</div>'
        )
        result = court_bot._extract_case_result(response)
        self.assertEqual(result.status, court_bot.MinistryLookupStatus.NOT_FOUND)

    def test_submits_official_case_form_with_fresh_token(self):
        session = self.make_ministry_session(
            '<div id="resultsContainer"><table><tr><td>تفاصيل القضية</td></tr></table></div>'
        )
        with patch.object(court_bot, '_new_moj_session', return_value=session):
            result = court_bot.fetch_case_from_moj('101', '1446', '1', '11')

        self.assertEqual(result.status, court_bot.MinistryLookupStatus.FOUND)
        args, kwargs = session.post.call_args
        self.assertEqual(args[0], court_bot.CASE_SEARCH_POST_URL)
        self.assertEqual(
            kwargs['data'],
            {
                'SideImNo': '14',
                'CourtTypeNo': '3',
                'PlaceCourtsNo': '145',
                'kindCaseNo': '1',
                'kindCasePrimeNo': '11',
                'CaseHandlyNo': '1446/101',
                '__RequestVerificationToken': 'fixture-token',
            },
        )
        self.assertEqual(kwargs['headers']['X-Requested-With'], 'XMLHttpRequest')

    def test_reports_ministry_connection_failure_as_unavailable(self):
        session = SimpleNamespace(
            headers={},
            get=Mock(
                side_effect=court_bot.requests.exceptions.ConnectionError(
                    'connection refused'
                )
            ),
            post=Mock(),
        )
        with patch.object(court_bot, '_new_moj_session', return_value=session):
            result = court_bot.fetch_case_from_moj('101', '1446', '1', '11')
        self.assertEqual(result.status, court_bot.MinistryLookupStatus.UNAVAILABLE)
        session.post.assert_not_called()

    def test_rejects_unrecognized_ministry_response_as_result(self):
        response = self.make_response('<html><body>unexpected page</body></html>')
        result = court_bot._extract_case_result(response)
        self.assertEqual(
            result.status,
            court_bot.MinistryLookupStatus.INVALID_RESPONSE,
        )

    def test_loads_fixed_court_and_case_types_from_official_form(self):
        session = self.make_ministry_session('')
        with patch.object(court_bot, '_new_moj_session', return_value=session):
            court_id, choices = court_bot.load_case_search_options()

        self.assertEqual(court_id, '145')
        self.assertEqual(choices, [('1', 'جزائية')])
        self.assertEqual(session.get.call_count, 2)


class DailySessionsLookupTests(unittest.TestCase):
    @staticmethod
    def make_response(body='', status_code=200, json_body=None):
        response = SimpleNamespace(
            text=body,
            status_code=status_code,
            raise_for_status=Mock(),
        )
        if json_body is not None:
            response.json = Mock(return_value=json_body)
        else:
            response.json = Mock(side_effect=ValueError('not JSON'))
        return response

    def make_sessions_page(self):
        return self.make_response(
            '<form id="searchForm" method="post" '
            'action="/JudgmentData/CustomRetCourtSittingByDate">'
            '<input type="hidden" name="__RequestVerificationToken" '
            'value="fixture-session-token">'
            '<select name="SideImNo">'
            '<option value="">اختر المحافظة</option>'
            '<option value="14">محافظة البيضاء</option>'
            '</select>'
            '<select name="PlaceCourtsNo"><option value="">اختر المحكمة</option>'
            '</select>'
            '<input type="date" name="SittingDate">'
            '</form>'
        )

    def make_sessions_session(self, result_html):
        return SimpleNamespace(
            headers={},
            get=Mock(side_effect=[
                self.make_sessions_page(),
                self.make_response(json_body=[
                    {'value': '145', 'text': 'محكمة البيضاء الابتدائية'},
                ]),
            ]),
            post=Mock(return_value=self.make_response(result_html)),
        )

    def test_normalizes_supported_session_dates(self):
        self.assertEqual(
            court_bot.parse_sitting_date('2026-10-21'),
            '2026-10-21',
        )
        self.assertEqual(
            court_bot.parse_sitting_date('٢١/١٠/٢٠٢٦'),
            '2026-10-21',
        )
        self.assertEqual(
            court_bot.parse_sitting_date('21/10/2026'),
            '2026-10-21',
        )
        self.assertIsNone(court_bot.parse_sitting_date('2026-13-40'))

    def test_loads_provinces_from_sessions_form(self):
        session = SimpleNamespace(
            headers={},
            get=Mock(return_value=self.make_sessions_page()),
        )
        with patch.object(court_bot, '_new_moj_session', return_value=session):
            provinces = court_bot.load_sessions_provinces()
        self.assertEqual(provinces, [('14', 'محافظة البيضاء')])
        session.get.assert_called_once_with(
            court_bot.SESSIONS_PAGE_URL,
            timeout=(4, 12),
        )

    def test_loads_dynamic_courts_using_sessions_endpoint_parameter(self):
        session = self.make_sessions_session('')
        with patch.object(court_bot, '_new_moj_session', return_value=session):
            courts = court_bot.fetch_sessions_courts('14')
        self.assertEqual(courts, [('145', 'محكمة البيضاء الابتدائية')])
        args, kwargs = session.get.call_args_list[1]
        self.assertEqual(args[0], court_bot.SESSIONS_COURTS_URL)
        self.assertEqual(kwargs['params'], {'sideImNo': '14'})

    def test_submits_official_sessions_form_with_fresh_token(self):
        session = self.make_sessions_session(
            '<div id="resultsContainer"><table>'
            '<tr><th>رقم القضية</th><th>الوقت</th></tr>'
            '<tr><td>101/1446</td><td>09:00</td></tr>'
            '</table></div>'
        )
        with patch.object(court_bot, '_new_moj_session', return_value=session):
            result = court_bot.fetch_daily_sessions_from_moj(
                '14',
                '145',
                '2026-10-21',
            )

        self.assertEqual(result.status, court_bot.MinistryLookupStatus.FOUND)
        self.assertIn('101/1446', result.data)
        args, kwargs = session.post.call_args
        self.assertEqual(args[0], court_bot.SESSIONS_PAGE_URL)
        self.assertEqual(
            kwargs['data'],
            {
                'SideImNo': '14',
                'PlaceCourtsNo': '145',
                'SittingDate': '2026-10-21',
                '__RequestVerificationToken': 'fixture-session-token',
            },
        )
        self.assertEqual(
            kwargs['headers']['X-Requested-With'],
            'XMLHttpRequest',
        )

    def test_extracts_empty_sessions_result(self):
        response = self.make_response(
            '<div id="resultsContainer">لا توجد جلسات</div>'
        )
        result = court_bot._extract_sessions_result(response)
        self.assertEqual(result.status, court_bot.MinistryLookupStatus.NOT_FOUND)


class WelcomeMessageTests(unittest.TestCase):
    @patch.object(court_bot.bot, 'send_photo')
    def test_sends_logo_with_requested_credit_and_welcome_text(self, send_photo):
        message = SimpleNamespace(chat=SimpleNamespace(id=123))

        court_bot.send_welcome(message)

        send_photo.assert_called_once()
        args, kwargs = send_photo.call_args
        self.assertEqual(args[0], 123)
        self.assertEqual(os.path.abspath(kwargs['photo'].name), court_bot.LOGO_PATH)
        self.assertIn('برمجة وتصميم/ احمد حسين محسون', kwargs['caption'])
        self.assertIn('734840710-771421919', kwargs['caption'])
        self.assertIn(
            'مرحباً بك في بوابة تقنية معلومات محكمة البيضاء الابتدائية للاستعلام القضائي الإلكتروني عن القضايا.',
            kwargs['caption'],
        )
        self.assertIn('اختر الخدمة المطلوبة:', kwargs['caption'])
        self.assertIsNotNone(kwargs['reply_markup'])
        buttons = [
            button['text']
            for row in kwargs['reply_markup'].keyboard
            for button in row
        ]
        self.assertEqual(
            buttons,
            [
                '🔍 الاستعلام المباشر عن قضية',
                'الاستعلام عن الجلسات اليومية',
                'ℹ️ معلومات النظام والملكية',
            ],
        )

    @patch.object(court_bot.bot, 'reply_to')
    def test_daily_sessions_button_loads_official_provinces(self, reply_to):
        message = SimpleNamespace(
            text=court_bot.DAILY_SESSIONS_BUTTON,
            chat=SimpleNamespace(id=123),
            from_user=SimpleNamespace(id=42),
        )
        court_bot.sessions_search_states.clear()
        with (
            patch.object(
                court_bot,
                'load_sessions_provinces',
                return_value=[('14', 'محافظة البيضاء')],
            ),
            patch.object(court_bot.bot, 'send_chat_action'),
            patch.object(court_bot.bot, 'edit_message_text'),
            patch.object(court_bot.bot, 'send_message') as send_message,
        ):
            reply_to.return_value = SimpleNamespace(message_id=3)
            court_bot.handle_menu(message)

        self.assertEqual(
            court_bot.sessions_search_states[(123, 42)]['step'],
            'province',
        )
        labels = [
            button['text']
            for row in send_message.call_args.kwargs['reply_markup'].keyboard
            for button in row
        ]
        self.assertEqual(
            labels,
            ['محافظة البيضاء', court_bot.CASE_CANCEL_BUTTON],
        )

    def test_sessions_flow_collects_province_court_and_date_in_order(self):
        court_bot.sessions_search_states.clear()
        initial = SimpleNamespace(
            text='',
            chat=SimpleNamespace(id=123),
            from_user=SimpleNamespace(id=42),
        )
        court_bot._save_sessions_state(initial, {
            'step': 'province',
            'provinces': [('14', 'محافظة البيضاء')],
        })
        with (
            patch.object(
                court_bot,
                'fetch_sessions_courts',
                return_value=[('145', 'محكمة البيضاء الابتدائية')],
            ),
            patch.object(court_bot, 'utc_today', return_value='2026-10-21'),
            patch.object(court_bot.bot, 'reply_to'),
            patch.object(
                court_bot,
                'process_daily_sessions_search',
            ) as process_search,
        ):
            court_bot.handle_menu(SimpleNamespace(
                text='محافظة البيضاء',
                chat=initial.chat,
                from_user=initial.from_user,
            ))
            state = court_bot._get_sessions_state(initial)
            self.assertEqual(state['step'], 'court')

            court_bot.handle_menu(SimpleNamespace(
                text='محكمة البيضاء الابتدائية',
                chat=initial.chat,
                from_user=initial.from_user,
            ))
            state = court_bot._get_sessions_state(initial)
            self.assertEqual(state['step'], 'date')

            final_message = SimpleNamespace(
                text='اليوم',
                chat=initial.chat,
                from_user=initial.from_user,
            )
            court_bot.handle_menu(final_message)

        process_search.assert_called_once_with(
            final_message,
            '14',
            'محافظة البيضاء',
            '145',
            'محكمة البيضاء الابتدائية',
            '2026-10-21',
        )
        self.assertIsNone(court_bot._get_sessions_state(initial))

    def test_case_search_fetches_live_options_and_starts_in_form_order(self):
        court_bot.case_search_states.clear()
        message = SimpleNamespace(
            text=court_bot.CASE_SEARCH_BUTTON,
            chat=SimpleNamespace(id=123),
            from_user=SimpleNamespace(id=42),
        )

        with (
            patch.object(
                court_bot,
                'load_case_search_options',
                return_value=('145', [('1', 'جزائية')]),
            ),
            patch.object(court_bot.bot, 'send_chat_action'),
            patch.object(
                court_bot.bot,
                'reply_to',
                return_value=SimpleNamespace(message_id=1),
            ),
            patch.object(court_bot.bot, 'edit_message_text') as edit_message,
            patch.object(court_bot.bot, 'send_message') as send_message,
        ):
            court_bot.handle_menu(message)

        self.assertIn('تم تثبيت الجهة', edit_message.call_args.args[0])
        self.assertEqual(
            court_bot.case_search_states[(123, 42)]['step'],
            'case_type',
        )
        keyboard = send_message.call_args.kwargs['reply_markup']
        labels = [button['text'] for row in keyboard.keyboard for button in row]
        self.assertEqual(labels, ['جزائية', court_bot.CASE_CANCEL_BUTTON])

    def test_case_flow_collects_type_subtype_then_case_number(self):
        court_bot.case_search_states.clear()
        initial = SimpleNamespace(
            text='',
            chat=SimpleNamespace(id=123),
            from_user=SimpleNamespace(id=42),
        )
        court_bot._save_case_state(initial, {
            'step': 'case_type',
            'court_id': '145',
            'case_types': [('1', 'جزائية')],
        })
        with (
            patch.object(
                court_bot,
                'fetch_case_subtypes',
                return_value=[('11', 'نوع فرعي')],
            ),
            patch.object(court_bot.bot, 'reply_to'),
            patch.object(
                court_bot,
                'process_search',
            ) as process_search,
        ):
            court_bot.handle_menu(SimpleNamespace(
                text='جزائية',
                chat=initial.chat,
                from_user=initial.from_user,
            ))
            state = court_bot._get_case_state(initial)
            self.assertEqual(state['step'], 'case_subtype')

            court_bot.handle_menu(SimpleNamespace(
                text='نوع فرعي',
                chat=initial.chat,
                from_user=initial.from_user,
            ))
            state = court_bot._get_case_state(initial)
            self.assertEqual(state['step'], 'case_number')

            final_message = SimpleNamespace(
                text='101/1446',
                chat=initial.chat,
                from_user=initial.from_user,
            )
            court_bot.handle_menu(final_message)

        process_search.assert_called_once_with(
            final_message,
            '1',
            '11',
            'جزائية',
            'نوع فرعي',
        )
        self.assertIsNone(court_bot._get_case_state(initial))


class UserRateLimiterTests(unittest.TestCase):
    def setUp(self):
        self.now = [100.0]
        self.limiter = court_bot.UserRateLimiter(
            limit=3,
            window_seconds=60,
            clock=lambda: self.now[0],
        )

    def test_blocks_requests_after_limit_until_window_expires(self):
        self.assertFalse(self.limiter.is_limited(42))
        self.assertFalse(self.limiter.is_limited(42))
        self.assertFalse(self.limiter.is_limited(42))
        self.assertTrue(self.limiter.is_limited(42))

        self.now[0] += 60
        self.assertFalse(self.limiter.is_limited(42))

    def test_tracks_users_independently(self):
        for _ in range(3):
            self.assertFalse(self.limiter.is_limited(42))
        self.assertTrue(self.limiter.is_limited(42))
        self.assertFalse(self.limiter.is_limited(43))

    @patch.object(
        court_bot,
        'fetch_case_from_moj',
        return_value=court_bot.MinistryLookupResult(
            status=court_bot.MinistryLookupStatus.FOUND,
            data='case data',
        ),
    )
    @patch.object(court_bot.bot, 'send_chat_action')
    @patch.object(court_bot.bot, 'reply_to', return_value=SimpleNamespace(message_id=1))
    @patch.object(court_bot.bot, 'edit_message_text')
    def test_process_search_stops_at_limit_with_clear_message(
        self,
        edit_message_text,
        reply_to,
        send_chat_action,
        fetch_case,
    ):
        messages = [
            SimpleNamespace(text='101/1446', chat=SimpleNamespace(id=1), from_user=SimpleNamespace(id=42))
            for _ in range(4)
        ]

        with patch.object(court_bot, 'search_rate_limiter', self.limiter):
            for message in messages:
                court_bot.process_search(message, '1', '11', 'جزائية', 'فرعي')

        self.assertEqual(fetch_case.call_count, 3)
        self.assertEqual(send_chat_action.call_count, 3)
        self.assertEqual(edit_message_text.call_count, 3)
        self.assertIn(
            'تجاوزت الحد المسموح للاستعلامات',
            reply_to.call_args_list[-1].args[1],
        )


if __name__ == '__main__':
    unittest.main()
